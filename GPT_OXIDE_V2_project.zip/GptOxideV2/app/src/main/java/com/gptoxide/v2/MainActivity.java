package com.gptoxide.v2;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16,9,27), PANEL = Color.rgb(31,19,49), PURPLE = Color.rgb(181,108,255), WHITE = Color.WHITE, MUTED = Color.rgb(190,174,210);
    private SharedPreferences prefs;
    private TextView pingResult;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("oxide", MODE_PRIVATE);
        buildUi();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void addCard(LinearLayout root, View child) {
        LinearLayout card = vertical(); card.setPadding(dp(16),dp(14),dp(16),dp(14));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(); bg.setColor(PANEL); bg.setCornerRadius(dp(18)); card.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,dp(12)); root.addView(card,p); card.addView(child);
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(WHITE); b.setAllCaps(false);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(); d.setColor(Color.rgb(111,54,170)); d.setCornerRadius(dp(14)); b.setBackground(d); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = vertical(); root.setPadding(dp(18),dp(20),dp(18),dp(24)); scroll.addView(root); setContentView(scroll);
        TextView brand = text("GPT OXIDE", 28, WHITE, true); root.addView(brand);
        TextView sub = text("V2  •  PURPLE GAMING HUB", 12, PURPLE, true); LinearLayout.LayoutParams sm = new LinearLayout.LayoutParams(-2,-2); sm.setMargins(0,dp(3),0,dp(18)); root.addView(sub,sm);

        LinearLayout status = vertical(); status.addView(text("ТВОЙ ИГРОВОЙ ЦЕНТР",15,WHITE,true));
        status.addView(text("Настройки и полезные инструменты для комфортной игры.",13,MUTED,false)); addCard(root,status);

        LinearLayout net = vertical(); net.addView(text("СЕТЬ",16,WHITE,true));
        pingResult = text("Задержка: ещё не проверялась",14,MUTED,false); LinearLayout.LayoutParams m = new LinearLayout.LayoutParams(-1,-2); m.setMargins(0,dp(8),0,dp(8)); net.addView(pingResult,m);
        Button ping = button("Проверить соединение"); net.addView(ping); ping.setOnClickListener(v -> testPing()); addCard(root,net);

        LinearLayout sens = vertical(); sens.addView(text("ПРОФИЛЬ УПРАВЛЕНИЯ",16,WHITE,true));
        sens.addView(text("Сохраняет твои заметки о настройках. Не меняет настройки самой игры.",12,MUTED,false));
        addSlider(sens,"Чувствительность камеры", "camera", 1, 200, 100);
        addSlider(sens,"Чувствительность прицела", "scope", 1, 200, 100);
        addCard(root,sens);

        LinearLayout tools = vertical(); tools.addView(text("ИНСТРУМЕНТЫ",16,WHITE,true));
        TextView note = text("• Игровой профиль\n• Быстрые заметки\n• Советы по стабильной работе телефона\n• Настройки интерфейса приложения",14,MUTED,false); LinearLayout.LayoutParams nm = new LinearLayout.LayoutParams(-1,-2); nm.setMargins(0,dp(8),0,0); tools.addView(note,nm); addCard(root,tools);

        LinearLayout tips = vertical(); tips.addView(text("СОВЕТ ПО ПРОИЗВОДИТЕЛЬНОСТИ",15,WHITE,true));
        tips.addView(text("Перед запуском игры закрой ненужные приложения и включи режим производительности, если он есть на твоём телефоне.",13,MUTED,false)); addCard(root,tips);
        TextView foot = text("GPT OXIDE V2  •  Companion app",11,MUTED,false); foot.setGravity(Gravity.CENTER); root.addView(foot);
    }
    private void addSlider(LinearLayout parent, String label, String key, int min, int max, int def) {
        TextView title = text(label + ": " + prefs.getInt(key,def),13,WHITE,true); parent.addView(title);
        SeekBar bar = new SeekBar(this); bar.setMax(max-min); bar.setProgress(prefs.getInt(key,def)-min); bar.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE)); bar.setThumbTintList(android.content.res.ColorStateList.valueOf(PURPLE)); parent.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b,int value,boolean user) { int actual=value+min; title.setText(label+": "+actual); if(user) prefs.edit().putInt(key,actual).apply(); }
            public void onStartTrackingTouch(SeekBar b) {} public void onStopTrackingTouch(SeekBar b) {}
        });
    }
    private void testPing() {
        pingResult.setText("Проверяем соединение…");
        executor.execute(() -> {
            String result;
            try { long start=System.nanoTime(); boolean ok=InetAddress.getByName("1.1.1.1").isReachable(2500); long ms=(System.nanoTime()-start)/1_000_000; result=ok?"Ответ получен примерно за "+ms+" мс":"Устройство не получило ответ. Это не точный игровой ping."; }
            catch(Exception e) { result="Не удалось проверить сеть."; }
            final String out=result; runOnUiThread(() -> pingResult.setText(out));
        });
    }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }
}
