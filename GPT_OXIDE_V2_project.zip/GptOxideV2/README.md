# GPT OXIDE V2

Android companion app project (Java, XML-free programmatic UI), designed for Android 6.0+ and target SDK 35.

## Included
- Purple gaming dashboard
- Saved sensitivity reference sliders (notes only; does not modify Oxide Survival)
- Basic network reachability check (not a true in-game ping measurement)
- Performance tips

## Safety and technical limits
This is a standalone companion app. It does not inject code into games, modify game files, draw ESP, automate aiming, alter bullets, or provide online-game cheats. Android does not expose another app's real FPS or in-game ping to an ordinary companion app, so those are not falsely reported.

## Build APK
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be created under `app/build/outputs/apk/debug/`.
